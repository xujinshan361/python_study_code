def receive():
    return "这是来自10086的短信"
