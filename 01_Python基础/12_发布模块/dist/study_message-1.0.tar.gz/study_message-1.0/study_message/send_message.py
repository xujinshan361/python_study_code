def send(text):
    print("正在发送 {0} 。。。".format(text))
